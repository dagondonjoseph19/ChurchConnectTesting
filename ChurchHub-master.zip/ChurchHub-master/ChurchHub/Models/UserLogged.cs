﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChurchHub
{
    public class UserLogged
    {
        public User_Account User_Account { get; set; }
        public User_Information User_Information { get; set; }
    }
}